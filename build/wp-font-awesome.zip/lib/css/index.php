<?php

/**
 * Index File
 *
 * This file defines the Child Theme's constants & tells WP not to update.
 *
 * @category   GetOne_Epik
 * @package    Index
 * @author     Travis Smith
 * @license    http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link       http://wpsmith.net/
 * @since      1.1.0
 */

 //Silence is golden.